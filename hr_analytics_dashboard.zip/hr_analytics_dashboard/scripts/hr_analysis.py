"""
HR Analytics - Data Analysis Script
Project 2: HR Analytics Dashboard

This script analyzes employee data to identify attrition patterns,
perform correlation analysis, and compute KPIs.

Run: python scripts/hr_analysis.py
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────
DATA_PATH  = Path(__file__).parent.parent / "data" / "employees.csv"
OUTPUT_DIR = Path(__file__).parent.parent / "data"
PLOT_DIR   = Path(__file__).parent.parent / "dashboard" / "plots"
PLOT_DIR.mkdir(parents=True, exist_ok=True)

PALETTE = {
    "attrition":   "#E05C5C",
    "retained":    "#5C9BE0",
    "accent":      "#F5A623",
    "bg":          "#0F1117",
    "card":        "#1C1F2E",
    "text":        "#E8E8F0",
}

sns.set_theme(style="darkgrid", palette="muted")
plt.rcParams.update({
    "figure.facecolor":  PALETTE["bg"],
    "axes.facecolor":    PALETTE["card"],
    "axes.edgecolor":    "#2E3250",
    "axes.labelcolor":   PALETTE["text"],
    "xtick.color":       PALETTE["text"],
    "ytick.color":       PALETTE["text"],
    "text.color":        PALETTE["text"],
    "grid.color":        "#2E3250",
    "font.family":       "monospace",
})


# ─────────────────────────────────────────
# 1. LOAD & CLEAN
# ─────────────────────────────────────────
def load_data(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["Attrition_Flag"]  = (df["Attrition"] == "Yes").astype(int)
    df["OverTime_Flag"]   = (df["OverTime"]  == "Yes").astype(int)
    df["IncomePerYear"]   = df["MonthlyIncome"] * 12
    print(f"✅  Loaded {len(df)} records | Columns: {list(df.columns)}")
    return df


# ─────────────────────────────────────────
# 2. KPIs
# ─────────────────────────────────────────
def compute_kpis(df: pd.DataFrame) -> dict:
    total       = len(df)
    left        = df["Attrition_Flag"].sum()
    attrition   = round(left / total * 100, 2)
    retention   = round(100 - attrition, 2)
    avg_tenure  = round(df["YearsAtCompany"].mean(), 1)
    avg_salary  = round(df["MonthlyIncome"].mean(), 0)
    avg_perf    = round(df["PerformanceRating"].mean(), 2)
    ot_risk     = round(df[df["OverTime_Flag"] == 1]["Attrition_Flag"].mean() * 100, 1)

    kpis = {
        "Total Employees":          total,
        "Attrition Rate (%)":       attrition,
        "Retention Rate (%)":       retention,
        "Employees Who Left":       int(left),
        "Avg Tenure (years)":       avg_tenure,
        "Avg Monthly Income ($)":   int(avg_salary),
        "Avg Performance Rating":   avg_perf,
        "OT Attrition Risk (%)":    ot_risk,
    }

    print("\n📊  KPI SUMMARY")
    print("─" * 40)
    for k, v in kpis.items():
        print(f"  {k:<30} {v}")
    return kpis


# ─────────────────────────────────────────
# 3. ATTRITION BY DEPARTMENT & ROLE
# ─────────────────────────────────────────
def attrition_by_group(df: pd.DataFrame):
    # By Department
    dept = (
        df.groupby("Department")["Attrition_Flag"]
          .agg(["mean", "sum", "count"])
          .rename(columns={"mean": "AttritionRate", "sum": "Left", "count": "Total"})
          .sort_values("AttritionRate", ascending=False)
    )
    dept["AttritionRate"] = (dept["AttritionRate"] * 100).round(1)
    print("\n📂  Attrition by Department:\n", dept)

    # By Job Role
    role = (
        df.groupby("JobRole")["Attrition_Flag"]
          .agg(["mean", "sum", "count"])
          .rename(columns={"mean": "AttritionRate", "sum": "Left", "count": "Total"})
          .sort_values("AttritionRate", ascending=False)
          .head(10)
    )
    role["AttritionRate"] = (role["AttritionRate"] * 100).round(1)
    print("\n🎭  Attrition by Top Job Roles:\n", role)
    return dept, role


# ─────────────────────────────────────────
# 4. CORRELATION ANALYSIS
# ─────────────────────────────────────────
def correlation_analysis(df: pd.DataFrame) -> pd.Series:
    numeric_cols = [
        "Age", "YearsAtCompany", "YearsExperience", "MonthlyIncome",
        "PerformanceRating", "JobSatisfaction", "WorkLifeBalance",
        "OverTime_Flag", "DistanceFromHome", "NumCompaniesWorked",
        "TrainingTimesLastYear", "EnvironmentSatisfaction",
    ]
    corr = df[numeric_cols + ["Attrition_Flag"]].corr()["Attrition_Flag"].drop("Attrition_Flag")
    corr_sorted = corr.sort_values(key=abs, ascending=False)
    print("\n🔗  Correlation with Attrition:\n", corr_sorted.to_string())
    return corr_sorted


# ─────────────────────────────────────────
# 5. SALARY & EXPERIENCE ANALYSIS
# ─────────────────────────────────────────
def salary_experience_analysis(df: pd.DataFrame):
    summary = df.groupby(["Department", "Attrition"]).agg(
        AvgSalary=("MonthlyIncome", "mean"),
        AvgExperience=("YearsExperience", "mean"),
        Count=("EmployeeID", "count"),
    ).round(1)
    print("\n💰  Salary & Experience by Department & Attrition:\n", summary)
    return summary


# ─────────────────────────────────────────
# 6. PLOT HELPERS
# ─────────────────────────────────────────
def _save(fig, name):
    path = PLOT_DIR / f"{name}.png"
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor=PALETTE["bg"])
    plt.close(fig)
    print(f"  💾  Saved → {path}")


def plot_attrition_by_department(df):
    dept_data = df.groupby(["Department", "Attrition"]).size().unstack(fill_value=0)
    dept_data.columns = ["Retained", "Left"]
    dept_data["AttritionRate"] = (dept_data["Left"] / (dept_data["Left"] + dept_data["Retained"]) * 100).round(1)

    fig, ax = plt.subplots(figsize=(9, 5))
    x = np.arange(len(dept_data))
    w = 0.38
    ax.bar(x - w/2, dept_data["Retained"], w, label="Retained", color=PALETTE["retained"], alpha=0.85)
    ax.bar(x + w/2, dept_data["Left"],     w, label="Attrited",  color=PALETTE["attrition"], alpha=0.85)
    for i, (_, row) in enumerate(dept_data.iterrows()):
        ax.text(i, max(row["Retained"], row["Left"]) + 0.3, f'{row["AttritionRate"]}%',
                ha="center", fontsize=9, color=PALETTE["accent"], fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(dept_data.index, fontsize=10)
    ax.set_ylabel("Employees")
    ax.set_title("Attrition vs Retention by Department", fontsize=13, fontweight="bold", pad=12)
    ax.legend(framealpha=0.2)
    fig.tight_layout()
    _save(fig, "attrition_by_department")


def plot_correlation_heatmap(corr_series):
    fig, ax = plt.subplots(figsize=(7, 6))
    colors = [PALETTE["attrition"] if v > 0 else PALETTE["retained"] for v in corr_series.values]
    bars = ax.barh(corr_series.index[::-1], corr_series.values[::-1], color=colors[::-1], edgecolor="none")
    ax.axvline(0, color="#555", linewidth=0.8)
    ax.set_xlabel("Correlation Coefficient")
    ax.set_title("Feature Correlation with Attrition", fontsize=13, fontweight="bold", pad=12)
    red_p  = mpatches.Patch(color=PALETTE["attrition"], label="Positive (risk ↑)")
    blue_p = mpatches.Patch(color=PALETTE["retained"],  label="Negative (risk ↓)")
    ax.legend(handles=[red_p, blue_p], framealpha=0.2)
    fig.tight_layout()
    _save(fig, "correlation_heatmap")


def plot_salary_distribution(df):
    fig, ax = plt.subplots(figsize=(9, 5))
    for label, color in [("No", PALETTE["retained"]), ("Yes", PALETTE["attrition"])]:
        subset = df[df["Attrition"] == label]["MonthlyIncome"]
        ax.hist(subset, bins=20, alpha=0.65, label=f"{'Retained' if label=='No' else 'Attrited'}",
                color=color, edgecolor="none")
    ax.set_xlabel("Monthly Income ($)")
    ax.set_ylabel("Count")
    ax.set_title("Salary Distribution: Retained vs Attrited", fontsize=13, fontweight="bold", pad=12)
    ax.legend(framealpha=0.2)
    fig.tight_layout()
    _save(fig, "salary_distribution")


def plot_overtime_attrition(df):
    ot_data = df.groupby(["OverTime", "Attrition"]).size().unstack(fill_value=0)
    ot_data.columns = ["Retained", "Left"]
    fig, ax = plt.subplots(figsize=(6, 5))
    x = np.arange(len(ot_data))
    w = 0.35
    ax.bar(x - w/2, ot_data["Retained"], w, label="Retained", color=PALETTE["retained"], alpha=0.85)
    ax.bar(x + w/2, ot_data["Left"],     w, label="Attrited",  color=PALETTE["attrition"], alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels(["No Overtime", "Overtime"], fontsize=11)
    ax.set_ylabel("Employees")
    ax.set_title("Overtime vs Attrition", fontsize=13, fontweight="bold", pad=12)
    ax.legend(framealpha=0.2)
    fig.tight_layout()
    _save(fig, "overtime_attrition")


def plot_tenure_vs_attrition(df):
    fig, ax = plt.subplots(figsize=(9, 5))
    bins = [0, 2, 5, 10, 15, 25, 40]
    labels = ["0-2y", "3-5y", "6-10y", "11-15y", "16-25y", "25y+"]
    df["TenureBand"] = pd.cut(df["YearsAtCompany"], bins=bins, labels=labels, right=True)
    tb = df.groupby("TenureBand")["Attrition_Flag"].mean() * 100
    ax.plot(tb.index.astype(str), tb.values, marker="o", color=PALETTE["accent"],
            linewidth=2.5, markersize=8, markerfacecolor=PALETTE["attrition"])
    ax.fill_between(range(len(tb)), tb.values, alpha=0.15, color=PALETTE["accent"])
    ax.set_xlabel("Tenure Band")
    ax.set_ylabel("Attrition Rate (%)")
    ax.set_title("Attrition Rate by Tenure Band", fontsize=13, fontweight="bold", pad=12)
    fig.tight_layout()
    _save(fig, "tenure_attrition")


def plot_satisfaction_vs_attrition(df):
    fig, axes = plt.subplots(1, 2, figsize=(11, 5))
    for ax, col, title in zip(
        axes,
        ["JobSatisfaction", "WorkLifeBalance"],
        ["Job Satisfaction", "Work-Life Balance"],
    ):
        sat = df.groupby(col)["Attrition_Flag"].mean() * 100
        ax.bar(sat.index.astype(str), sat.values, color=PALETTE["attrition"], alpha=0.8, edgecolor="none")
        ax.set_xlabel(f"{title} Score (1=Low, 4=High)")
        ax.set_ylabel("Attrition Rate (%)")
        ax.set_title(f"Attrition by {title}", fontsize=12, fontweight="bold")
    fig.tight_layout()
    _save(fig, "satisfaction_attrition")


# ─────────────────────────────────────────
# 7. EXPORT SUMMARIES AS CSV
# ─────────────────────────────────────────
def export_summaries(df, kpis, corr_series, dept_data):
    # KPI table
    pd.DataFrame.from_dict(kpis, orient="index", columns=["Value"]).to_csv(
        OUTPUT_DIR / "kpis.csv"
    )

    # Department summary
    dept_full = df.groupby("Department").agg(
        Total=("EmployeeID", "count"),
        Left=("Attrition_Flag", "sum"),
        AttritionRate=("Attrition_Flag", "mean"),
        AvgSalary=("MonthlyIncome", "mean"),
        AvgTenure=("YearsAtCompany", "mean"),
        AvgSatisfaction=("JobSatisfaction", "mean"),
    ).round(2)
    dept_full["AttritionRate"] = (dept_full["AttritionRate"] * 100).round(1)
    dept_full.to_csv(OUTPUT_DIR / "department_summary.csv")

    # Correlation
    corr_series.reset_index().rename(columns={"index": "Feature", "Attrition_Flag": "Correlation"}).to_csv(
        OUTPUT_DIR / "correlations.csv", index=False
    )

    print("\n✅  Summaries exported to /data/")


# ─────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────
def main():
    print("=" * 50)
    print("  HR ANALYTICS — Data Analysis Pipeline")
    print("=" * 50)

    df           = load_data(DATA_PATH)
    kpis         = compute_kpis(df)
    dept_data, _ = attrition_by_group(df)
    corr_series  = correlation_analysis(df)
    salary_experience_analysis(df)

    print("\n🖼️   Generating plots …")
    plot_attrition_by_department(df)
    plot_correlation_heatmap(corr_series)
    plot_salary_distribution(df)
    plot_overtime_attrition(df)
    plot_tenure_vs_attrition(df)
    plot_satisfaction_vs_attrition(df)

    export_summaries(df, kpis, corr_series, dept_data)

    print("\n🎉  Analysis complete!")
    print(f"    Plots → {PLOT_DIR}")
    print(f"    Data  → {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
